import{s}from"../chunks/scheduler.C7Wo8M4i.js";import{S as t,i as e}from"../chunks/index.CV8hfPSa.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
