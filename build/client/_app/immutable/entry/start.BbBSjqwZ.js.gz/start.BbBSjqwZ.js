import{h as a}from"../chunks/entry.CEfYAMar.js";export{a as start};
