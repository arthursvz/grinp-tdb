function i(t){const r={};for(const n in t){const e=t[n];e!==void 0&&(r[n]=e)}return r}function o(t){return function(r,n){if(n===void 0)return;const e=t[r];e&&e.set(n)}}export{o as g,i as r};
